package backendProjeto.backendProjeto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendProjetoApplicationTests {

	@Test
	void contextLoads() {
	}

}
