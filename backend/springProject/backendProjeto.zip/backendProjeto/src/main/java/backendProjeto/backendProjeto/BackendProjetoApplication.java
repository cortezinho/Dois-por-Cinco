package backendProjeto.backendProjeto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendProjetoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendProjetoApplication.class, args);
	}

}
